#!/bin/bash

program_name="Code Generator"
public_command="codegen"
version="1.0.0"
author="Jamal Kaksouri"
email="jamal.kaksouri@gmail.com"
description="A tool for generating unique, randomized codes"

echo "Installing $program_name version $version"
echo "Public command: $public_command"
echo "Author: $author"
echo "Email: $email"
echo "Description: $description"
echo "Copyright (c) $author. All rights reserved"

sudo cp codegen /usr/local/bin/

sudo chmod +x /usr/local/bin/codegen

echo "$program_name has been installed successfully"
